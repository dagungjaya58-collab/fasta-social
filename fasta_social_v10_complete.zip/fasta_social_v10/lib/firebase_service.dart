import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';

class FastaService {
  static final auth = FirebaseAuth.instance;
  static final db = FirebaseFirestore.instance;
  static final storage = FirebaseStorage.instance;

  static User? get user => auth.currentUser;

  static Future<UserCredential> signUp(String email, String password, String name) async {
    final cred = await auth.createUserWithEmailAndPassword(email: email.trim(), password: password);
    await cred.user!.updateDisplayName(name.trim());
    await db.collection('users').doc(cred.user!.uid).set({
      'uid': cred.user!.uid,
      'name': name.trim(),
      'email': email.trim(),
      'createdAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
    return cred;
  }

  static Future<UserCredential> signIn(String email, String password) =>
      auth.signInWithEmailAndPassword(email: email.trim(), password: password);

  static Future<void> signOut() => auth.signOut();

  static Stream<QuerySnapshot<Map<String, dynamic>>> posts() =>
      db.collection('posts').orderBy('createdAt', descending: true).limit(50).snapshots();

  static Future<String> uploadFile(File file, String path) async {
    final ref = storage.ref(path);
    await ref.putFile(file);
    return ref.getDownloadURL();
  }

  static Future<void> createPost({required String caption, String? mediaUrl, String? mediaType}) async {
    final u = user!;
    await db.collection('posts').add({
      'uid': u.uid,
      'name': u.displayName ?? 'FASTA User',
      'caption': caption.trim(),
      'mediaUrl': mediaUrl,
      'mediaType': mediaType,
      'likes': 0,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  static Future<void> toggleLike(String postId, bool liked) async {
    final ref = db.collection('posts').doc(postId);
    await db.runTransaction((tx) async {
      final snap = await tx.get(ref);
      final data = snap.data() ?? {};
      final current = (data['likes'] ?? 0) as num;
      tx.update(ref, {'likes': (current + (liked ? -1 : 1)).clamp(0, 1000000000)});
      final likeRef = ref.collection('likes').doc(user!.uid);
      if (liked) {
        tx.delete(likeRef);
      } else {
        tx.set(likeRef, {'uid': user!.uid, 'createdAt': FieldValue.serverTimestamp()});
      }
    });
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>> messages(String peerUid) {
    final ids = [user!.uid, peerUid]..sort();
    return db.collection('chats').doc(ids.join('_')).collection('messages')
        .orderBy('createdAt', descending: true).limit(100).snapshots();
  }

  static Future<void> sendMessage(String peerUid, String text) async {
    final value = text.trim();
    if (value.isEmpty) return;
    final ids = [user!.uid, peerUid]..sort();
    final chatRef = db.collection('chats').doc(ids.join('_'));
    await chatRef.set({
      'members': ids,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
    await chatRef.collection('messages').add({
      'senderId': user!.uid,
      'text': value,
      'createdAt': FieldValue.serverTimestamp(),
    });
    await chatRef.set({
      'members': ids,
      'lastMessage': value,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }
}
