import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import 'firebase_options.dart';
import 'firebase_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Object? error;
  try {
    await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  } catch (e) {
    error = e;
  }
  runApp(FastaApp(firebaseError: error));
}

class FastaApp extends StatelessWidget {
  final Object? firebaseError;
  const FastaApp({super.key, this.firebaseError});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'FASTA',
    theme: ThemeData(useMaterial3: true, brightness: Brightness.dark, colorSchemeSeed: Colors.deepPurple),
    home: firebaseError != null ? SetupErrorPage(error: firebaseError!) : const AuthGate(),
  );
}

class SetupErrorPage extends StatelessWidget {
  final Object error;
  const SetupErrorPage({super.key, required this.error});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Icon(Icons.cloud_off_rounded, size: 72),
      const SizedBox(height: 16),
      const Text('Firebase belum terhubung', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      Text('Periksa konfigurasi Firebase dan jalankan ulang aplikasi.\n\n$error', textAlign: TextAlign.center),
    ]))),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder(
    stream: FastaService.auth.authStateChanges(),
    builder: (_, snap) => snap.data == null ? const LoginPage() : const FastaShell(),
  );
}

class LoginPage extends StatefulWidget { const LoginPage({super.key}); @override State<LoginPage> createState() => _LoginPageState(); }
class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController(); final password = TextEditingController(); final name = TextEditingController();
  bool register = false, loading = false; String? error;
  Future<void> submit() async {
    setState(() { loading = true; error = null; });
    try {
      if (register) { await FastaService.signUp(email.text, password.text, name.text); }
      else { await FastaService.signIn(email.text, password.text); }
    } on FirebaseAuthException catch (e) { setState(() => error = e.message ?? e.code); }
    catch (e) { setState(() => error = e.toString()); }
    if (mounted) setState(() => loading = false);
  }
  @override Widget build(BuildContext context) => Scaffold(body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 430), child: Column(children: [
    const Icon(Icons.bolt_rounded, size: 82), const SizedBox(height: 8),
    const Text('FASTA', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w900)),
    const Text('Social • Chat • Video', style: TextStyle(color: Colors.white60)), const SizedBox(height: 30),
    if (register) TextField(controller: name, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'Nama', prefixIcon: Icon(Icons.person_outline))),
    if (register) const SizedBox(height: 12),
    TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.email_outlined))), const SizedBox(height: 12),
    TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password', prefixIcon: Icon(Icons.lock_outline))), const SizedBox(height: 16),
    if (error != null) Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(error!, style: const TextStyle(color: Colors.redAccent))),
    SizedBox(width: double.infinity, child: FilledButton(onPressed: loading ? null : submit, child: Text(loading ? 'Memproses...' : register ? 'Buat akun' : 'Masuk'))),
    TextButton(onPressed: loading ? null : () => setState(() { register = !register; error = null; }), child: Text(register ? 'Sudah punya akun? Masuk' : 'Belum punya akun? Daftar')),
  ])))));
}

class FastaShell extends StatefulWidget { const FastaShell({super.key}); @override State<FastaShell> createState() => _FastaShellState(); }
class _FastaShellState extends State<FastaShell> {
  int index = 0;
  final pages = const [FeedPage(), ExplorePage(), UploadPage(), ChatPage(), ProfilePage()];
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('FASTA', style: TextStyle(fontWeight: FontWeight.w900)), actions: [IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationsPage())), icon: const Icon(Icons.notifications_none_rounded))]),
    body: IndexedStack(index: index, children: pages),
    bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (i) => setState(() => index = i), destinations: const [
      NavigationDestination(icon: Icon(Icons.play_circle_outline), label: 'FYP'), NavigationDestination(icon: Icon(Icons.search), label: 'Explore'),
      NavigationDestination(icon: Icon(Icons.add_box_outlined), label: 'Upload'), NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'Chat'), NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profil')]),
  );
}

class FeedPage extends StatelessWidget { const FeedPage({super.key});
  @override Widget build(BuildContext context) => StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
    stream: FastaService.posts(), builder: (_, snap) {
      if (snap.hasError) return Center(child: Text('Feed belum siap: ${snap.error}'));
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final docs = snap.data!.docs; if (docs.isEmpty) return const Center(child: Text('Belum ada postingan. Upload konten pertama!'));
      return PageView.builder(scrollDirection: Axis.vertical, itemCount: docs.length, itemBuilder: (_, i) => PostCard(doc: docs[i]));
    });
}

class PostCard extends StatefulWidget { final QueryDocumentSnapshot<Map<String,dynamic>> doc; const PostCard({super.key, required this.doc}); @override State<PostCard> createState() => _PostCardState(); }
class _PostCardState extends State<PostCard> {
  bool liked = false;
  @override Widget build(BuildContext context) { final d = widget.doc.data(); final media = d['mediaUrl'] as String?; final type = d['mediaType'] as String?;
    return Stack(fit: StackFit.expand, children: [Container(color: Colors.black, child: media == null ? const Center(child: Icon(Icons.play_circle_fill, size: 90)) : type == 'video' ? _Video(url: media) : Image.network(media, fit: BoxFit.contain, errorBuilder: (_,__,___) => const Center(child: Icon(Icons.broken_image)))),
      Positioned(left: 16, right: 82, bottom: 24, child: DecoratedBox(decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(16)), child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(d['name'] ?? 'FASTA User', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), if ((d['caption'] ?? '').toString().isNotEmpty) Text(d['caption'].toString())])))),
      Positioned(right: 12, bottom: 24, child: Column(children: [IconButton(onPressed: () async { await FastaService.toggleLike(widget.doc.id, liked); if (mounted) setState(() => liked = !liked); }, icon: Icon(liked ? Icons.favorite : Icons.favorite_border), iconSize: 34), Text('${d['likes'] ?? 0}'), const SizedBox(height: 12), const Icon(Icons.comment_outlined, size: 30), const SizedBox(height: 4), const Text('Chat')]))]);
  }
}

class _Video extends StatefulWidget { final String url; const _Video({required this.url}); @override State<_Video> createState() => _VideoState(); }
class _VideoState extends State<_Video> { late VideoPlayerController c; @override void initState(){super.initState(); c=VideoPlayerController.networkUrl(Uri.parse(widget.url))..initialize().then((_){if(mounted){setState((){}); c.setLooping(true); c.play();}});} @override void dispose(){c.dispose();super.dispose();} @override Widget build(BuildContext context)=>c.value.isInitialized ? Center(child: AspectRatio(aspectRatio:c.value.aspectRatio, child:VideoPlayer(c))) : const Center(child:CircularProgressIndicator()); }

class ExplorePage extends StatelessWidget { const ExplorePage({super.key}); @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[const SearchBar(hintText:'Cari pengguna, video, hashtag...'),const SizedBox(height:20),const Text('Trending',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),...['#fasta','#fyp','#viral','#indonesia','#cikarang'].map((x)=>ListTile(leading:const Icon(Icons.local_fire_department_outlined),title:Text(x),subtitle:const Text('Sedang ramai di FASTA')))]); }

class UploadPage extends StatefulWidget { const UploadPage({super.key}); @override State<UploadPage> createState()=>_UploadPageState(); }
class _UploadPageState extends State<UploadPage> {
  final caption=TextEditingController(); XFile? picked; bool video=false, uploading=false;
  Future<void> pick(bool isVideo) async { final p=ImagePicker(); final x= isVideo ? await p.pickVideo(source:ImageSource.gallery) : await p.pickImage(source:ImageSource.gallery, imageQuality:90); if(x!=null)setState(()=>picked=x); video=isVideo; }
  Future<void> publish() async { if(picked==null && caption.text.trim().isEmpty)return; setState(()=>uploading=true); try { String? url; if(picked!=null) url=await FastaService.uploadFile(File(picked!.path),'posts/${FastaService.user!.uid}/${DateTime.now().millisecondsSinceEpoch}_${picked!.name}'); await FastaService.createPost(caption:caption.text,mediaUrl:url,mediaType:picked==null?null:video?'video':'image'); setState(()=>picked=null); caption.clear(); if(mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Postingan berhasil dibuat'))); } catch(e){ if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Gagal upload: $e'))); } finally { if(mounted)setState(()=>uploading=false); } }
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(20),children:[const Text('Buat konten',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),const SizedBox(height:16),Row(children:[Expanded(child:FilledButton.icon(onPressed:uploading?null:()=>pick(false),icon:const Icon(Icons.photo),label:const Text('Foto'))),const SizedBox(width:10),Expanded(child:FilledButton.icon(onPressed:uploading?null:()=>pick(true),icon:const Icon(Icons.video_library),label:const Text('Video')))]),if(picked!=null)Padding(padding:const EdgeInsets.symmetric(vertical:16),child:Text('Dipilih: ${picked!.name}')),TextField(controller:caption,maxLines:4,decoration:const InputDecoration(labelText:'Caption',border:OutlineInputBorder())),const SizedBox(height:16),FilledButton.icon(onPressed:uploading?null:publish,icon:const Icon(Icons.publish),label:Text(uploading?'Mengunggah...':'Publikasikan'))]);
}

class ChatPage extends StatelessWidget { const ChatPage({super.key});
  Future<void> openChat(BuildContext context) async {
    final uid = TextEditingController();
    final name = TextEditingController(text: 'FASTA User');
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(title: const Text('Chat baru'), content: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: uid, decoration: const InputDecoration(labelText: 'UID pengguna')), TextField(controller: name, decoration: const InputDecoration(labelText: 'Nama tampilan'))]), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(context, uid.text.trim().isNotEmpty), child: const Text('Buka'))]));
    if (ok == true && context.mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => ChatDetailPage(peerUid: uid.text.trim(), name: name.text.trim())));
  }
  @override Widget build(BuildContext context)=>Stack(children:[ListView(children:[const ListTile(leading:CircleAvatar(child:Icon(Icons.group)),title:Text('FASTA Community'),subtitle:Text('Grup komunitas')),const Divider(),ListTile(leading:const CircleAvatar(child:Icon(Icons.person_add_alt_1)),title:const Text('Mulai chat pribadi'),subtitle:const Text('Masukkan UID pengguna FASTA'),onTap:()=>openChat(context))]),Positioned(right:18,bottom:18,child:FloatingActionButton(onPressed:()=>openChat(context),child:const Icon(Icons.chat))) ]); }

class ChatDetailPage extends StatefulWidget { final String peerUid; final String name; const ChatDetailPage({super.key,required this.peerUid,required this.name}); @override State<ChatDetailPage> createState()=>_ChatDetailPageState(); }
class _ChatDetailPageState extends State<ChatDetailPage>{ final text=TextEditingController(); @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(widget.name)),body:Column(children:[Expanded(child:StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream:FastaService.messages(widget.peerUid),builder:(_,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());return ListView(reverse:true,children:s.data!.docs.map((d){final m=d.data();final mine=m['senderId']==FastaService.user!.uid;return Align(alignment:mine?Alignment.centerRight:Alignment.centerLeft,child:Container(margin:const EdgeInsets.all(6),padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:mine?Colors.deepPurple:Colors.white12,borderRadius:BorderRadius.circular(16)),child:Text(m['text']??'')));}).toList());})),SafeArea(child:Row(children:[Expanded(child:TextField(controller:text,decoration:const InputDecoration(hintText:'Tulis pesan...',border:OutlineInputBorder()))),IconButton(onPressed:()async{await FastaService.sendMessage(widget.peerUid,text.text);text.clear();},icon:const Icon(Icons.send))]))])); }

class ProfilePage extends StatelessWidget { const ProfilePage({super.key}); @override Widget build(BuildContext context){final u=FastaService.user!;return ListView(padding:const EdgeInsets.all(20),children:[const CircleAvatar(radius:46,child:Icon(Icons.person,size:46)),const SizedBox(height:12),Center(child:Text(u.displayName??'FASTA User',style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold))),Center(child:Text(u.email??'')),const SizedBox(height:24),ListTile(leading:const Icon(Icons.email_outlined),title:const Text('Email'),subtitle:Text(u.email??'')),ListTile(leading:const Icon(Icons.fingerprint),title:const Text('UID'),subtitle:Text(u.uid)),const SizedBox(height:20),FilledButton.icon(onPressed:()=>FastaService.signOut(),icon:const Icon(Icons.logout),label:const Text('Keluar'))]);}}

class NotificationsPage extends StatelessWidget { const NotificationsPage({super.key}); @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Notifikasi')),body:const Center(child:Text('Notifikasi akan muncul di sini.'))); }
