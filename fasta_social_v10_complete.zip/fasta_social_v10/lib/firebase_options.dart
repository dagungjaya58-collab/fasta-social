// Generated for the FASTA Firebase project.
// Project ID: fasta-feb35

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      throw UnsupportedError(
        'FASTA currently targets Android/iOS. Configure Web separately if needed.',
      );
    }

    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        throw UnsupportedError(
          'FASTA Firebase is not configured for this platform yet.',
        );
    }
  }

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyCZy7ChMQpx4F8kt7YMOTHsd1nMd9_ueMk',
    appId: '1:820187016736:ios:4d7ba959ceff85fe089645',
    messagingSenderId: '820187016736',
    projectId: 'fasta-feb35',
    storageBucket: 'fasta-feb35.firebasestorage.app',
    iosBundleId: 'com.fasta.social',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyDb_PRvcFQs-oPUvMnqYN3yBBjIa_lLA08',
    appId: '1:820187016736:android:fd682459c7337d4e089645',
    messagingSenderId: '820187016736',
    projectId: 'fasta-feb35',
    storageBucket: 'fasta-feb35.firebasestorage.app',
  );
}
